## Module <base_account_budget>

#### 07.11.2023
#### Version 17.0.1.0.0
#### ADD
- Initial commit for Budget Management

#### 02.01.2024
#### Version 17.0.1.0.1
#### FIX
- Bug Fixed, states and tracking_visibility parameter removed from the fields of budget.budget model.

#### 19.02.2025
#### Version 17.0.1.0.2
#### FIX
- Bug Fixed, sum was not viewing in tree view in budget form view.