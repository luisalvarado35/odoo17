{
    'name': 'POS Receipt Customization',
    'version': '1.0',
    'summary': 'Personalización de tickets POS (fuentes y tamaños)',
    'description': 'Ajusta el tamaño de letra en encabezado, cliente, cuerpo y pie de los tickets POS.',
    'category': 'Point of Sale',
    'author': 'Disertel',
    'depends': ['point_of_sale'],
    'data': [],
    'assets': {
        'point_of_sale._assets_pos': [
            'custom_pos_receipt/static/src/css/receipt_custom.css',
            'custom_pos_receipt/static/src/xml/custom_receipt_templates.xml',
        ],
    },
    'installable': True,
    'application': False,
}
