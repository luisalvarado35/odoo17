from odoo import models, api, fields
from collections import defaultdict
from datetime import datetime
import pytz

class PosSession(models.Model):
    _inherit = 'pos.session'

    @api.model
    def build_sessions_report(self, session_ids):
        # Llamar a la implementación base si existe
        try:
            results = super().build_sessions_report(session_ids)
        except AttributeError:
            results = {}
        
        sessions = self.browse(session_ids)
        for session in sessions:
            # Asegurarse de que session_data siempre esté definida
            session_data = results.get(session.id, {})
            
            # Obtener datos base si no están presentes
            base_data = self._get_base_session_data(session)
            session_data.update(base_data)
            
            # Agregar datos específicos del módulo
            session_data.update({
                'product_details': self._get_product_details(session),
                'taxes': self._get_tax_details(session),
                'payments': self._get_payment_details(session),
                'gross_profit': self._get_gross_profit(session),
                'net_profit': self._get_net_profit(session),
                'product_costs': self._get_product_costs(session),
                # Mantener compatibilidad con datos existentes
                'cash_in': session_data.get('cash_in', []),
                'cash_out': session_data.get('cash_out', []),
                'reversal_total': session_data.get('reversal_total', 0),
                'reversal_orders_detail': session_data.get('reversal_orders_detail', {}),
                'refund_total': session_data.get('refund_total', 0),
                'discounts_total': session_data.get('discounts_total', 0),
                'closing_total': session_data.get('closing_total', 0),
            })
            
            results[session.id] = session_data
        
        return results

    def _get_base_session_data(self, session):
        """Genera los datos base del reporte"""
        tz = pytz.timezone(self.env.user.tz or 'UTC')
        start_at = session.start_at.astimezone(tz).strftime("%Y-%m-%d %H:%M:%S") if session.start_at else ""
        stop_at = session.stop_at.astimezone(tz).strftime("%Y-%m-%d %H:%M:%S") if session.stop_at else False
        
        return {
            'current_date': fields.Date.context_today(self),
            'current_time': datetime.now(tz).strftime("%H:%M:%S"),
            'start_at': start_at,
            'stop_at': stop_at,
            'state': session.state,
            'orders_count': session.order_count,
            'cash_register_balance_start': session.cash_register_balance_start,
            'seller': session.user_id.name,
            'sales_total': session.total_payments_amount,
        }

    def _get_product_details(self, session):
        """Calcula los detalles de productos vendidos"""
        orders = session.order_ids.filtered(
            lambda o: o.state in ['paid', 'invoiced', 'done']
        )
        
        product_details = defaultdict(lambda: {
            'product_name': '',
            'quantity': 0,
            'unit_price': 0.0,
            'subtotal': 0.0
        })
        
        for order in orders:
            for line in order.lines:
                product = line.product_id
                product_key = f"{product.id}_{line.price_unit}"
                
                if not product_details[product_key]['product_name']:
                    product_details[product_key]['product_name'] = product.display_name
                
                product_details[product_key]['quantity'] += line.qty
                product_details[product_key]['unit_price'] = line.price_unit
                product_details[product_key]['subtotal'] += line.price_subtotal_incl
        
        return sorted(product_details.values(), key=lambda p: p['subtotal'], reverse=True)

    def _get_tax_details(self, session):
        """Calcula los detalles de impuestos correctamente"""
        orders = session.order_ids.filtered(
            lambda o: o.state in ['paid', 'invoiced', 'done']
        )
        
        tax_groups = {}
        
        for order in orders:
            for line in order.lines:
                price = line.price_unit * (1 - (line.discount or 0.0) / 100.0)
                taxes_res = line.tax_ids.compute_all(
                    price, 
                    session.currency_id, 
                    line.qty, 
                    product=line.product_id, 
                    partner=line.order_id.partner_id
                )
                
                for tax in taxes_res['taxes']:
                    tax_id = tax['id']
                    tax_record = self.env['account.tax'].browse(tax_id)
                    
                    if tax_id not in tax_groups:
                        tax_groups[tax_id] = {
                            'tax_name': tax_record.name,
                            'tax_total': 0.0,
                            'net_total': 0.0,
                            'rate': tax_record.amount
                        }
                    
                    tax_groups[tax_id]['tax_total'] += tax['amount']
                    tax_groups[tax_id]['net_total'] += tax['base']
        
        return sorted(tax_groups.values(), key=lambda t: t['tax_total'], reverse=True)

    def _get_payment_details(self, session):
        """Obtiene los detalles de pagos agrupados por método"""
        orders = session.order_ids.filtered(
            lambda o: o.state in ['paid', 'invoiced', 'done']
        )
        
        payment_methods = {}
        currency = session.currency_id
        
        for order in orders:
            for payment in order.payment_ids:
                pm = payment.payment_method_id
                if pm.id not in payment_methods:
                    payment_methods[pm.id] = {
                        'name': pm.name,
                        'amount': 0.0,
                        'currency': currency.symbol,
                        'count': 0
                    }
                payment_methods[pm.id]['amount'] += payment.amount
                payment_methods[pm.id]['count'] += 1
        
        return sorted(payment_methods.values(), key=lambda p: p['amount'], reverse=True)

    def _get_product_costs(self, session):
        """Calcula el costo total de los productos vendidos"""
        orders = session.order_ids.filtered(
            lambda o: o.state in ['paid', 'invoiced', 'done']
        )
        
        total_cost = 0.0
        for order in orders:
            for line in order.lines:
                total_cost += line.product_id.standard_price * line.qty
        
        return total_cost

    def _get_gross_profit(self, session):
        """Calcula el beneficio bruto (ventas - costo de ventas)"""
        total_sales = session.total_payments_amount
        total_cost = self._get_product_costs(session)
        return total_sales - total_cost

    def _get_net_profit(self, session):
        """Calcula el beneficio neto (bruto - impuestos)"""
        gross_profit = self._get_gross_profit(session)
        total_taxes = sum(tax['tax_total'] for tax in self._get_tax_details(session))
        return gross_profit - total_taxes