{
    "name": "POS Kiosk Categories",
    "version": "17.0.1.1.0",
    "depends": ["point_of_sale"],
    "assets": {
        "point_of_sale._assets_pos": [
            "pos_kiosk_categories/static/src/js/products_widget.js",
            "pos_kiosk_categories/static/src/xml/product_list.xml"
        ]
    },
    "category": "Point of Sale",
    "summary": "Muestra las categorías al centro estilo kiosco con navegación de subcategorías.",
    "installable": True,
    "application": False,
    "license": "LGPL-3"
}