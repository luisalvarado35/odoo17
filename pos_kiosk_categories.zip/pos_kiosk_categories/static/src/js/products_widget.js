/** @odoo-module **/

import { patch } from "@web/core/utils/patch";
import { ProductsWidget } from "@point_of_sale/app/screens/product_screen/product_list/product_list";
import { useState } from "@odoo/owl";

patch(ProductsWidget.prototype, {

    setup() {
        super.setup();
        this.kioskNav = useState({ stack: [] });
    },

    // ──────────────────────────────────────────────────────────────────────────
    // Helpers de modelo
    // Odoo 17 Community guarda las categorias en this.pos.db.category_by_id
    // No en this.pos.models["pos.category"] como en Enterprise
    // ──────────────────────────────────────────────────────────────────────────
    _allCategories() {
        try {
            // Odoo 17 Community - PosDB (fuente principal)
            if (this.pos.db && this.pos.db.category_by_id) {
                return Object.values(this.pos.db.category_by_id);
            }
            // Odoo 17 con nuevo sistema de modelos reactivos (Enterprise/variantes)
            if (this.pos.models && this.pos.models["pos.category"]) {
                const m = this.pos.models["pos.category"];
                return typeof m.getAll === "function" ? m.getAll() : Object.values(m);
            }
            // Alias alternativo
            if (this.pos.pos_category_by_id) {
                return Object.values(this.pos.pos_category_by_id);
            }
        } catch (e) {
            console.warn("[KioskCategories] Error cargando categorias:", e);
        }
        return [];
    },

    // Resuelve el ID del padre independientemente del formato: [id,name] | {id} | numero
    _parentId(cat) {
        if (!cat.parent_id) return null;
        if (Array.isArray(cat.parent_id)) return cat.parent_id[0] || null;
        if (typeof cat.parent_id === "object") return cat.parent_id.id || null;
        return cat.parent_id || null;
    },

    // Hijos directos de parentId; null = categorias raiz
    _getChildren(parentId) {
        const all = this._allCategories();
        let result;
        if (parentId === null) {
            const allIds = new Set(all.map(c => c.id));
            result = all.filter(c => {
                const pid = this._parentId(c);
                return !pid || !allIds.has(pid);
            });
        } else {
            result = all.filter(c => this._parentId(c) === parentId);
        }
        return result.sort(
            (a, b) => (a.sequence ?? 0) - (b.sequence ?? 0) || a.name.localeCompare(b.name)
        );
    },

    // ──────────────────────────────────────────────────────────────────────────
    // Getters reactivos (usados en el XML)
    // ──────────────────────────────────────────────────────────────────────────

    get kioskShowCategories() {
        return !this.pos.searchProductWord && !this.pos.selectedCategoryId;
    },

    get kioskCanGoBack() {
        return this.kioskNav.stack.length > 0;
    },

    get kioskCategoriesToShow() {
        const stack = this.kioskNav.stack;
        const parentId = stack.length > 0 ? stack[stack.length - 1] : null;
        return this._getChildren(parentId);
    },

    get kioskCurrentCatId() {
        const s = this.kioskNav.stack;
        return s.length > 0 ? s[s.length - 1] : null;
    },

    // ──────────────────────────────────────────────────────────────────────────
    // Handlers de navegacion (usados en el XML)
    // ──────────────────────────────────────────────────────────────────────────

    kioskSelectCategory(cat) {
        if (this._getChildren(cat.id).length > 0) {
            this.kioskNav.stack.push(cat.id);
            this.pos.setSelectedCategoryId(0);
        } else {
            this.pos.setSelectedCategoryId(cat.id);
        }
    },

    kioskGoBack() {
        if (this.pos.selectedCategoryId) {
            this.pos.setSelectedCategoryId(0);
        } else if (this.kioskNav.stack.length > 0) {
            this.kioskNav.stack.pop();
        }
    },

    kioskReset() {
        this.pos.setSelectedCategoryId(0);
        this.kioskNav.stack.splice(0);
    },
});