{
    "name": "Product Margin and Margin Rate",
    "version": "17.0.1.0.0",
    "author": "Disertel",
    "category": "Product",
    "website": "www.disertel.com",
    "license": "AGPL-3",
    "depends": ["account", "product"],
    "data": [
        "views/view_product_product.xml",
        "views/view_product_template.xml",
    ],
    "installable": True,
    "application": False,
    "images": ["static/description/product_form.png"],
}
