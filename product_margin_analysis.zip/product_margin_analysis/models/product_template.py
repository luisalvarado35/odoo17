from odoo import api, fields, models


class ProductTemplate(models.Model):
    _inherit = "product.template"

    gain_percent = fields.Float(
        string="Porcentaje de beneficio %",
        help="Porcentaje de beneficio aplicado sobre el precio de coste. "
     "El precio de venta se calcula automáticamente como: "
     "Precio de venta = Coste × (1 + % beneficio / 100)."
    )

    standard_margin = fields.Float(
        string="Margen teórico",
        help="El margen teórico se calcula como: [ precio de venta (sin impuestos) - coste ]. "
         "No se basa en valores históricos. "
         "Ten en cuenta si los impuestos están incluidos o no. "
         "Si no hay precio de venta, el margen será negativo.",
        digits="Product Price",
        compute="_compute_margins",
        store=True,
        readonly=True,
    )
    standard_margin_rate = fields.Float(
        string="Margen teórico (%)",
        help="Porcentaje del margen sobre el precio de venta sin impuestos. "
         "Se calcula como: [ Margen teórico / precio de venta (sin impuestos) ]. "
         "No se basa en valores históricos. Si no hay precio de venta, el valor será 999,0.",
        digits="Product Price",
        compute="_compute_margins",
        store=True,
        readonly=True,
    )
    standard_markup_rate = fields.Float(
        string="Incremento teórico (%)",
        help="Porcentaje de incremento aplicado sobre el coste. "
         "Se calcula como: [ Margen teórico / coste ]. "
         "No se basa en valores históricos. Si no hay coste, el valor será 999,0.",
        digits="Product Price",
        compute="_compute_margins",
        store=True,
        readonly=True,
    )

    @api.depends("list_price", "standard_price")
    def _compute_margins(self):
        for rec in self:
            margin = rec.list_price - rec.standard_price
            rec.standard_margin = margin
            rec.standard_margin_rate = (margin / rec.list_price * 100) if rec.list_price else 0.0
            rec.standard_markup_rate = (margin / rec.standard_price * 100) if rec.standard_price else 0.0

    @api.onchange("gain_percent", "standard_price")
    def _onchange_gain_percent(self):
        for rec in self:
            if rec.standard_price and rec.gain_percent:
                rec.list_price = rec.standard_price * (1 + rec.gain_percent / 100)
