# models/__init__.py
from . import product_template
